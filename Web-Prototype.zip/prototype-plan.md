# Usage Keeper — 前端与展示图表设计方案

> 文档类型：PRD 风格设计简报（原型 / Dashboard 类）
> 设计系统：Apple（媒体与消费电子向，冷峻克制、单一蓝色强调色、大量留白）
> 交付物：单文件 HTML 高保真原型（Web Prototype 插件，`dashboard.html`）

## 1. 意图摘要

现有 `cpa-plugin-usage-keeper` 的 Dashboard（`dashboard/template.html`）功能已相当完整：5 个标签页（By Model / All Events / Pricing / Health / Quota）、暗色主题、时间范围筛选、环形缓冲、脱敏、配额监控（OpenCode Go / GLM Coding / DeepSeek / Ollama Cloud）。但它的视觉语言是 Slate/Tailwind 风格（`#0f172a` 等），与「Apple」设计系统并不一致；更重要的是**展示层严重依赖表格与 CSS 进度条，缺乏真正的数据可视化**——时间序列趋势、Provider/模型分布、成本构成等关键洞察没有被图表呈现。

本方案的目标不是重写后端，而是：**在保留现有数据契约（API 返回结构不变）的前提下，重新设计前端的信息架构、视觉系统与图表体系**，让一个「用量核算工具」升级为「可一眼看懂 AI 支出的分析面板」。

## 2. 目标用户与场景

- **用户**：使用 CLIProxyAPI 的开发者 / 个人开发者、小团队，需要实时了解「花了多少 token / 多少钱、哪个模型最费钱、配额还剩多少、服务是否健康」。
- **场景**：
  1. 打开面板快速扫一眼「今天 / 本周花费多少」。
  2. 定位「哪个模型 / 哪个 Provider 是成本大头」。
  3. 排查某次请求失败、延迟异常。
  4. 检查 OpenCode / Ollama / DeepSeek 等订阅配额是否快用完。
  5. 核对/手动维护模型定价。

## 3. 现有数据结构（锁定契约，不可破坏）

以下为 Go 侧 `types.go` 已定义、前端通过 fetch 消费的结构。设计必须**逐字段复用**，不臆造新字段；图表所需的新聚合（如按时间分桶）若无后端支持，则在前端从已有数据推导。

### 3.1 聚合摘要 — `GET /api/summary` → `summaryResponse`
| 字段 | 类型 | 说明 |
|---|---|---|
| `total_requests` | int64 | 请求总数 |
| `total_tokens` / `input_tokens` / `output_tokens` | int64 | token 拆分 |
| `failed_requests` | int64 | 失败请求数 |
| `unique_models` | int64 | 独立模型数 |
| `avg_latency_ms` | float64 | 平均延迟 |
| `cache_hit_rate` | float64 | 缓存命中率 |
| `range_hours` | int | 时间窗口小时数 |

### 3.2 模型拆分 — `GET /api/models` → `modelBreakdown[]`
`provider` / `model` / `requests` / `input_tokens` / `output_tokens` / `total_tokens` / `cached_tokens` / `cost`。
→ 这是成本构成、Provider 分布、模型排行榜的**唯一数据源**。

### 3.3 事件流 — `GET /api/events` → `eventsResponse`
`events[]`（`timestamp` / `provider` / `model` / `input_tokens` / `output_tokens` / `total_tokens` / `latency_ms` / `failed` / `cache_hit_rate` / `auth_id` / `executor_type`）+ `total` / `limit` / `offset`。
→ 时间序列趋势、延迟分布、失败率、executor 来源可从这里推导。

### 3.4 健康 — `GET /api/health`
`status` / `alerts[]` / `runtime{}`（`uptime_seconds` / `ring_buffer_used` / `ring_buffer_size` / `total_requests` / 缓存命中率 / `last_write_duration_ms` / `storage_write_errors`）/ `storage{}`（`db_file_size` / `db_path`）。

### 3.5 配额 — `GET /api/{opencode|glmcoding|deepseek|ollama}-quota`
`quotaResponse.accounts[]` → `quotaAccount`（`type` / `name` / `workspace_id` / `success` / `updated_at` / `plan` / `windows[]` / `model_usage[]` / `error`）。`quotaWindow` 含 `label` / `used` / `remaining` / `total` / `unit` / `reset_in_sec` / `status_text` / `models[]`。

### 3.6 定价 — `GET /api/prices`
`prices` 为 `map[model] {prompt, completion, cache, auto_synced}`，价格单位 $/1M token。

## 4. 关键发现（现有实现的缺口）

1. **图表缺失**：`summary` 卡片里的 sparkline 用的是 `Math.random()` 假数据（见 `renderCards`），是「装饰性占位」而非真实趋势 —— 这违反「不得伪造数据」原则，是本方案首要修复点。
2. **视觉与设计系统脱节**：当前用 Slate 蓝灰（`#0f172a`/`#60a5fa`），非 Apple 的黑/白中性 + 单一 `#0071e3` 蓝。需整体重绑 token。
3. **无成本洞察**：`cost` 已存在于数据中，但没有「总花费」「成本 Top N」「Provider 成本占比」等视图。
4. **无时间序列**：Events 有 `timestamp`，但没有任何按时间聚合的趋势图。
5. **数据源可覆盖**：现有 API 足以支撑主要图表，无需新增后端端点（除「按时间分桶趋势」可能需前端聚合 events，或建议后端增加可选 `bucket` 参数——见 §9 待确认项）。

## 5. 屏幕与信息架构

### 5.1 全局骨架
- **顶栏**（Chrome）：品牌名 + 时间范围选择 + 自动刷新 + 主题切换 + 手动刷新。Apple 化：细边框、半透明、静默。
- **摘要卡片行**（4 张，替换现有 5 张）：Requests、Tokens、Cost（**新增**，从 models 求和）、Cache Hit。每张卡片用真实数据 sparkline（非随机）。
- **主标签页**（沿用 5 个，但重排与增强）：
  1. **Overview**（新增，替代「By Model」成为默认首页）——把分散的指标汇成「一眼看全」。
  2. **By Model**（保留，增强为带图表的排行榜）。
  3. **All Events**（保留，表格 + 过滤器）。
  4. **Quota**（保留，四家订阅余额）。
  5. **Pricing**（保留，定价管理）。
  6. **Health**（保留，健康监控）。

> 待确认：是否新增 Overview 作为默认首屏，还是维持「By Model」为默认。

### 5.2 Overview（新增默认首屏）
- **顶部 KPI 带**：总花费、总 token、请求数、平均延迟、缓存命中率。
- **成本时间序列**（主图）：按时间桶的 Cost 趋势（面积图 + 折线）。
- **Provider 成本占比**（环形/水平堆叠条）：从 `models` 按 provider 聚合 `cost`。
- **模型成本 Top 5**（水平条形）：成本排序。
- **失败率 / 延迟** 迷你指标。

### 5.3 By Model
- 保留「Detailed / Aggregated」切换（`aggregateModels` 已实现模糊归一）。
- 表格列保留：Model / Requests / Tokens（In/Out 双色条）/ Cost。
- 顶部加一张「Token 构成」堆叠条或 Provider 分布小图。

### 5.4 All Events
- 表格保留，列：Time / Model / Source(executor) / Tokens / Cache / Latency / Status。
- 点击行 → 抽屉详情（保留现有 drawer，Apple 化其视觉）。
- 保留失败行展开错误详情、`quickFilterEvents` 跳转。

### 5.5 Quota
- 四家 Provider 切换（现有 `setQuotaProvider` 逻辑）。
- 账号卡片：`windows[]` 用量进度条、`plan`、`updated_at`、刷新/移除。
- 进度条用 Apple 语义色（成功绿 / 告警黄 / 危险红），阈值视觉化。

### 5.6 Pricing
- 分组表格（现有 `classifyProvider` 分组折叠）。
- 表单 + Sync from modelprice.boxtech.icu（保留）。

### 5.7 Health
- Status 顶栏（ok/warn/danger 呼吸灯）+ alerts。
- 指标网格：Ring Buffer 用量、缓存命中率、写入延迟、DB 大小、uptime。
- Ring Buffer 用环形进度（Apple 风格圆环）。

## 6. 图表方案（数据可视化核心）

> 原则：真实数据、填充式编码（非空轮廓）、单一蓝色强调 + 中性色，语义色仅用于告警/失败。

| 图表 | 数据源 | 图表类型 | 用途 |
|---|---|---|---|
| KPI sparklines | summary + events | 迷你面积/折线 | 卡片内真实趋势 |
| 成本趋势 | events 按时间桶聚合 | 面积图（主图） | 时间序列总览 |
| Provider 成本占比 | models 按 provider 聚合 | 环形图 或 水平堆叠条 | 谁在花钱 |
| 模型成本 Top N | models 按 cost 排序 | 水平条形 | 成本大头 |
| Token 输入/输出 | models | 堆叠条 / 双色条 | In/Out 比例 |
| 延迟分布 / 失败率 | events | 折线/柱状 | 健康洞察 |
| Ring Buffer / 配额 | health / quota | 环形进度 + 进度条 | 容量与额度 |
| 定价表格 | prices | 表格（分组） | 管理 |

**技术选择**：优先自绘轻量 SVG（延续现有无依赖、`sparkline` 手写 SVG 的思路），避免引入 Chart.js/D3 等重量级 CDN 依赖（插件是单文件、进程内运行、可能无外网）。折线/面积/条形/环形均可用约 100 行内 SVG 生成器实现。

## 7. 视觉系统（绑定 Apple token）

- 色板：`--bg #ffffff` / `--surface #f5f5f7` / `--fg #1d1d1f` / `--muted #6e6e73` / `--border #d2d2d7` / `--accent #0071e3`（详见已注入的 `tokens.css`）。
- 暗色主题：Apple 深黑 `#000000` 场景 + graphite 阶梯（`#272729`→`#2a2a2c`），而非 Slate 蓝灰。
- 字体：Display `SF Pro Display`，正文 `SF Pro Text`，mono `SF Mono`（回退 Inter / Helvetica）。
- 节奏：8px 网格；展示区 100px 章节留白，数据区更紧凑；半径分层（8/12/18/980px）。
- 强调色纪律：蓝色仅用于主 CTA、链接、focus、选中态；每屏 ≤2 处蓝色。语义色（成功绿/警告黄/危险红）仅用于配额进度与失败状态，面积 <5%。
- 交互态：hover 增亮（`--accent-hover #0077ed`）、active 加深（`--accent-active #0066cc`）、focus 蓝色 halo 环；对比度不降低。

## 8. 组件与状态清单

- **组件**：卡片（摘要）、按钮（primary/ghost/pill）、标签页、表格、进度条、环形进度、抽屉、表单字段、toast、徽章、图标（线性 SVG）。
- **状态**：每个可聚焦元素的 `:focus-visible`；按钮 hover/active/disabled；标签页 active；进度条阈值色；抽屉拖拽（保留现有 velocity 手势逻辑）。
- **响应式**：Apple 断点（374/375-640/641-833/834-1023/1024+）；移动端单列、表格卡片化、标签横向滚动。
- **可访问性**：对比度 ≥4.5:1（正文）/3:1（大文字图标）；`prefers-reduced-motion` 降级；`prefers-contrast` 增强；`prefers-color-scheme` 自动暗色。

## 9. 待确认项 / 开放问题

- [ ] **默认首屏**：是否新增「Overview」作为默认，还是保留「By Model」为默认？（推荐：新增 Overview）
- [ ] **成本趋势的时间分桶**：是否需要后端在 `/api/events` 或 `/api/summary` 增加按时间聚合（bucket）端点？若否，前端自行聚合 `events`（受 `limit=100` 限制，长窗口趋势会不准确）——**这是影响图表真实性的关键决策**。
- [ ] **是否保留现有 5 标签页名称**，还是按本文重命名（如「By Model」→「Models」）？
- [ ] **交付语言**：当前 UI 文案为英文，是否全部中文化（本项目默认简体中文）？
- [ ] **暗色是否作为默认**（Apple 展示页多为浅色，开发者工具常默认暗色）？

## 10. 验收检查（Delivery Checklist）

- [ ] 所有图表用真实数据，无 `Math.random()` 假数据。
- [ ] 绑定 Apple `tokens.css`，无裸 hex（`:root` 外）。
- [ ] 单一蓝色强调，每屏 ≤2 处；语义色仅告警/失败。
- [ ] 5+ 标签页（或 6 个含 Overview）可切换，抽屉/过滤器/配额切换可用。
- [ ] 交互态（hover/focus/active/disabled）逐项校验，对比度不下降。
- [ ] 移动端无横向滚动。
- [ ] `data-od-id` 标注关键区域与卡片。
- [ ] 无占位符、无空区块。

## 11. 下一步

1. 请审阅本文档，重点回答 **§9 待确认项**（尤其是「成本趋势分桶」与「是否中文化」）。
2. 确认或修改后，回复「开始设计」/「按此方案生成」，我将进入 Design 阶段产出 `dashboard.html` 高保真原型。
